# PrivaSee
BSComSci Thesis

This repository contains the source files for our BSCS thesis titled, "PrivaSee: Monitoring and Parental Control Access using Face Verification", at Bicol University College of Science.
